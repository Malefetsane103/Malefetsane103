import React from 'react';
import './App.css';
import logo from './wings.jpg';  // Renamed the import to avoid conflict

const Logo = () => {
    return (
        <div id="logoContainer">
            <img src={logo} alt="Wings Cafe Logo" />
        </div>
    );
};

export default Logo;
